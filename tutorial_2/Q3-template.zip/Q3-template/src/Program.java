import java.util.Scanner;


public class Program {

    // TODO: Define a printArray method that prints an Array of plant (or flower) objects

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String input;
        // TODO: Declare an Array of size 100 called myGarden that can hold object of type plant

        // TODO: Declare variables - plantName, plantCost, colorOfFlowers, isAnnual

        // TODO: Write a loop to read plant information

        // TODO: Call the method printArray to print myGarden
     
    }
}

