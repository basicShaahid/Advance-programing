public class Circle implements Comparable, Printable{
    private double radius;
    public Circle(double r){
        this.radius = r;
    }

    // TODO: Implement the method compareTo.


    // TODO: Implement the method printInfo

}
