public class EmployeeManager extends EmployeePerson {
    private int numManaged;

    // ***********************************************************************

    // TODO: Create a Constructor which takes a parameter nManaged and assign its value to instance variable numManaged

    // ***********************************************************************

    // TODO: Implement the method getNumManaged()


    // ***********************************************************************
    // TODO: Implement the method printInfo() from Printable interface


    // ***********************************************************************

    // TODO: Implement the getAnnualBonus method. A manager's annual bonus
    //        is calculated as 10% of the manager's annual salary.



    // ***********************************************************************
}