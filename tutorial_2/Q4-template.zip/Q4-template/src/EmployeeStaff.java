public class EmployeeStaff extends EmployeePerson {
    private String managerName;

    // ***********************************************************************

    // TODO: Create Constructor which takes parameter name and assign its value to instance variable managerName


    // ***********************************************************************

    // TODO: Implement method getManagerName()


    // ***********************************************************************
    // TODO: Implement the printInfo method from Printable interface


    // ***********************************************************************

    // TODO: Implement the getAnnualBonus method. A staff's annual bonus
    //        is calculated as 7.5% of the employee's annual salary.



}
