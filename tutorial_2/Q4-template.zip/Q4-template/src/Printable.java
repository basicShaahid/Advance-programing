public interface Printable {
    public void printInfo();
}
